# LDP — Local Data Protocol
## Official Specification v1.0 · March 2026

> **LDP is the protocol. PACT is the product.**
> Like Linux kernel → Android OS.
> Like JSON-RPC → MCP protocol.
> Like V8 engine → Node.js runtime.

---

## 1. What LDP Is

LDP (Local Data Protocol) is an open protocol for giving any application complete, live, intelligent understanding of a user's personal data — without that data ever leaving the user's device.

**LDP is a Personal Context Runtime.**

One line. Drop it in. Everything underneath is automatic. Forever.

```python
import ldp
# This one line gives any app:
# · Every app on the system discovered automatically
# · All local data read and understood (encrypted or not)
# · RAG indexed locally using nomic-embed-text
# · LangGraph agents running in background
# · MCP agents connectable for world actions
# · Zero raw data sent to any cloud
```

### What LDP Is Not

| Not | Because |
|---|---|
| Not a model | LDP does not generate text or images |
| Not an agent | Agents run inside LDP |
| Not a cloud service | Everything on user's machine |
| Not a replacement for MCP | LDP speaks MCP as one of its adapters |
| Not a framework requiring manual setup | LDP auto-discovers everything |

---

## 2. Core Definitions

**LDP Engine** — runtime on user's machine. Reads data, runs agents, manages memory, routes AI.

**LDP Agent** — knows WHO the user is. Personal context. Connects to MCP agents.

**MCP Agent** — knows WHAT tools exist (GitHub, Slack, Calendar). Receives context from LDP Agent. Executes actions.

**Connector** — JSON descriptor. Tells LDP how to find, decrypt, read one app. No code required.

**PACT** — Personal AI Context Runtime. Product name. What developers ship to users.

---

## 3. The 6 Capabilities (What Every Developer Gets)

```
1. KNOW     — reads every app, understands every context
2. REMEMBER — builds persistent memory of the user
3. REASON   — Agentic RAG finds relevant context per question
4. WATCH    — LangGraph agents run background, alert on triggers
5. ACT      — LDP agent + MCP agent execute real-world tasks
6. LEARN    — Knowledge Distillation from Claude, Federated Learning
```

---

## 4. Architecture — 8 Layers

### Layer 0 — Auto-Discovery + AI Auto-Decrypt

Runs on startup. Zero configuration. Three AI sub-agents:

**Fingerprint Agent** — reads first 16 bytes of every file found:
- `SQLite format 3` → plain SQLite, read directly
- Random bytes at offset 0 → SQLCipher, trigger Decrypt Agent
- Specific pattern → wxSQLite3, known derivation
- Unknown → pattern match vs 50+ app signatures

**Decrypt Agent** — resolves encryption per app:
- Chrome: AES-128-CBC, key from macOS Keychain via PBKDF2(`saltysalt`, 1003 iter), IV = 16 spaces
- Signal: AES-128-CBC, key from macOS Keychain via PBKDF2, IV = encBuffer[3:19]
- WhatsApp Android: `wa-crypt-tools` pip package via ADB
- WhatsApp iOS: iTunes backup unencrypted `ChatStorage.sqlite`
- iMessage: plain SQLite `~/Library/Messages/chat.db`
- Unknown: log `requires_manual_decrypt`, surface to developer

**Schema Agent** — maps raw field names to human meaning:
- `ZSFMESSAGE` → iMessage messages
- `messages` + `chats` → messaging app
- `urls` + `visits` → browser history
- `like_count` + `taken_at` → social media
- Confidence < 0.6 → ask user to confirm before use

**One-time permission:** Full Disk Access (macOS). Granted once at install. Never asked again.

**Honest limitations:**
- WeChat macOS: Apple SIP blocks key extraction. `not_available_macos`.
- iOS live app data: unavailable without iTunes backup.

---

### Layer 1 — Agentic RAG Engine

```
Standard RAG:  embed → find chunks → send to AI → answer
Agentic RAG:   embed → find chunks → evaluate quality
                → if weak: refine query + search again
                → cross-source: check all connected apps
                → verify answer vs source
                → answer + confidence + source attribution
```

- Embedding: `nomic-embed-text` via Ollama (274MB, CPU, 40ms/chunk)
- Fallback: BM25 keyword scoring
- Progressive indexing: last 7 days first (3s), then 30 days (background), then all
- Score: `recency × 0.3 + relevance × 0.6 + source_weight × 0.1`

---

### Layer 2 — Knowledge Distillation + Memory

**Distillation — 3 modes:**

| Mode | How | Privacy |
|---|---|---|
| Cascade | Local handles ~48% of queries privately | Zero cloud |
| Distil-Once | Claude solves task once, local learns reasoning, runs forever after | Minimal cloud |
| Teach-Method | Send task type not data, Claude returns method, local applies | Zero personal data sent |

**Memory — 3 tiers:**

| Tier | What | Location |
|---|---|---|
| Hot | Active context | RAM ~200k tokens |
| Warm | Vector index | Local disk (nomic embeddings) |
| Cold | Raw files | Local disk (unlimited) |

GDPR Right to be Forgotten: delete local files. Nothing in cloud. Compliant by architecture.

---

### Layer 3 — LangGraph Multi-Agent Engine

LDP wraps LangGraph. Every agent is a LangGraph node.

**Supervisor Agent** — full user context, routes to specialists.

**Specialist Sub-Agents:**
- Calendar · Finance · Social · Work · Health · Custom (JSON-defined)

**Task automation flow:**
```
TRIGGER (pattern detected / user request / schedule)
  ↓
PLAN (LangGraph breaks into steps, assesses risk)
  ↓
LOW RISK  → auto-execute (summarise, remind, draft, index)
HIGH RISK → pause for human approval (send, delete, pay, post)
  ↓
EXECUTE via MCP agents
  ↓
AUDIT (immutable local log)
```

---

### Layer 4 — Temporal Context Graph

Time-based graph connecting all apps by timestamp and semantic similarity.

Only LDP can surface these insights (requires reading multiple apps simultaneously):
- "You spend more on weekends after high-stress work weeks"
- "Your best commits happen Tuesday mornings"
- "Team communication drops before every delivery"

---

### Layer 5 — Privacy Engine (3 Layers)

**A — Local processing:** Ollama reads and summarises raw data on device. Never sent.

**B — Anonymisation before any cloud call:**
- Names → `[Person A]`, `[Person B]`
- Phones → `[Phone]`
- Locations → `[Location]`
- De-anonymisation happens locally after cloud responds.

**C — Differential Privacy:** Mathematical noise added to context chunks. Claude gets meaning. Raw data cannot be reverse-engineered.

**Semantic Compression:** 1000 messages → 20 semantic facts (99% reduction, zero meaning loss).

---

### Layer 6 — LDP as MCP Server + Cloud Bridge

**LDP exposes itself as MCP server.**

Claude, Cursor, any MCP client connects to LDP directly. Auto-generated tools:
- `ldp_chrome_query`, `ldp_signal_query`, `ldp_git_query`
- `ldp_calendar_query`, `ldp_shell_query`, `ldp_cross_app_insight`

**Cloud bridge:**
```
Local Ollama (always-on fallback)
    ↓ when complex query
LDP Anonymiser
    ↓ anonymised context only
Developer's cloud (NVIDIA NIM — 2x faster, zero config)
    ↓ AI answer
LDP De-anonymiser
    ↓ real names restored locally
User sees full intelligent answer
Raw data never left device
```

---

### Layer 7 — Federated Learning + Intent Prediction

**Federated Learning:** 1000 users train locally → share only model weights → LDP smarter for everyone. Zero raw data shared. Proven pattern: Google Gboard.

**Intent Prediction:** Learn user patterns → surface what they need before asking. 100% local.

---

### Layer 8 — LDP Identity + Data Passport

**LDP Identity:** One profile across all PACT apps. Memory and preferences follow user.

**Data Passport:** Verified facts user controls. Share with apps on request only.
- "Software developer · Python + TypeScript · prefers concise answers"
- Verified from actual user data. Never inferred from form inputs.

---

## 5. Protocol Messages

**Transport:** JSON-RPC 2.0 on HTTP. Binary 23-byte header on stdio/WebSocket.

### 5.1 Core Message Types (9 — frozen at v1.0)

| # | Type | Direction | Purpose |
|---|---|---|---|
| 0x01 | HANDSHAKE | Client→Engine | Open session, exchange capabilities |
| 0x02 | DISCOVER | Client→Engine | Find data sources for named app |
| 0x03 | QUERY | Client→Engine | Natural language question + context |
| 0x04 | SCHEMA | Engine internal | Map fields to semantic meaning |
| 0x05 | STREAM | Engine→Client | Token-by-token AI response (SSE) |
| 0x06 | SUBSCRIBE | Client→Engine | Persistent channel for live updates |
| 0x07 | INSIGHT | Engine→Client | Proactive AI finding, unprompted |
| 0x08 | ERROR | Engine→Client | Typed fault with recovery instruction |
| 0x09 | AUDIT | Engine internal | Append to local audit.log |

Extension types: 0x10–0xFF. Unknown extension = silently ignored. Forward compatible.

### 5.2 Message Envelope

```json
{
  "msg_id": "ldp_uuid_v4",
  "version": "1.0.0",
  "type": "QUERY",
  "timestamp_utc": "2026-03-21T14:30:00Z",
  "session_id": "sess_abc123",
  "reply_to": null,
  "auth": {
    "method": "NONE | BEARER | OAUTH2 | APIKEY | ADB | FILE_PATH",
    "credential": "<AES-256-GCM encrypted blob>",
    "scope": ["read:content", "read:profile"]
  },
  "source": {
    "adapter": "SQLITE | FILE | REST | ADB | WEBSOCKET | MCP",
    "app_name": "chrome",
    "schema_version": "2024-03"
  },
  "payload": {
    "intent": "what sites did I visit most this week?",
    "ai_target": "OLLAMA | GROQ | GEMINI | GPT | CLAUDE | AUTO",
    "stream": true
  },
  "meta": {
    "audit_log": true,
    "cache_ttl": 3600
  }
}
```

### 5.3 STREAM Response Fields

```json
{
  "type": "STREAM",
  "token": "Based on your Chrome history...",
  "is_final": false,
  "data_freshness": "2026-03-21T13:45:00Z",
  "context_coverage_pct": 94.2,
  "source_errors": {"signal": "permission_denied"},
  "confidence": 0.91
}
```

---

## 6. Connector Descriptor Format

```json
{
  "id": "instagram_export",
  "version": "1.0.0",
  "display_name": "Instagram",
  "adapter": "FILE",
  "auth": "NONE",
  "file_pattern": "**/instagram/**/*.json",
  "schema_hints": [
    "taken_at=timestamp",
    "like_count=engagement",
    "caption=text"
  ],
  "known_paths": {
    "darwin": "~/Downloads",
    "win32": "C:/Users/{user}/Downloads",
    "linux": "~/Downloads"
  },
  "description": "Reads Instagram GDPR data export",
  "tags": ["social", "photos"],
  "min_ldp_version": "1.0.0"
}
```

**Connector Signing:** SHA-256 hash at install. Re-verified every startup. Mismatch = refuse + alert.
Prevents AI coding assistants from autonomously modifying connectors (real incident during LDP development — this requirement is mandatory, not optional).

---

## 7. Permission Model — 4 Layers

```
Layer 1: Connector declares allowed_scopes[]     ← ceiling
Layer 2: User grants subset at connection time    ← narrowed
Layer 3: Query declares needed_scope[]            ← must be ⊆ granted
Layer 4: Engine strips out-of-scope fields        ← enforced at read
```

E502 (scope violation) is **silent to AI**. AI never knows field existed. No workaround attempts.

---

## 8. Schema Confidence System

```json
{
  "raw_field": "like_count",
  "semantic_label": "engagement_count",
  "confidence": 0.94,
  "source": "known | inferred | hint_override | user_confirmed"
}
```

| Confidence | Action |
|---|---|
| ≥ 0.9 | Proceed silently |
| 0.6–0.9 | Proceed + flag |
| < 0.6 | Ask user to confirm |

`user_confirmed` = highest trust tier. Locked permanently. Never re-inferred.

**Honest limitation:** AI can be confidently wrong. Confidence score shows uncertainty — not protection against confident errors. `user_confirmed` is the only full mitigation. Stated clearly so users understand the risk.

---

## 9. Error Taxonomy

| Range | Category | Auto Response |
|---|---|---|
| E1xx | Auth | E100 token_expired → refresh; E101 invalid → re-auth |
| E2xx | Source | E200 not_found → DISCOVER; E201 schema_changed → guard |
| E3xx | AI | E300 unavailable → fallback chain; E301 overflow → chunk |
| E4xx | Schema | E400 unknown_field → infer; E401 mismatch → lock+alert |
| E5xx | Security | E500 mac_invalid → block; E502 write_attempt → deny |
| E6xx | Transport | E600 drop → reconnect; E601 interrupted → resume |
| E7xx | Engine | E700 overloaded → queue; E701 indexing → ETA |

---

## 10. AI Fallback Chain

```
Ollama (local, unlimited, always on)
  ↓ unavailable
Groq free (131k ctx, 30 rpm)
  ↓ unavailable
Gemini free (1M ctx, 60 rpm)
  ↓ unavailable
GPT-4o (128k ctx, 500 rpm, paid)
  ↓ unavailable
Claude (200k ctx, paid)
  ↓ all fail
E300 → surface to user
```

---

## 11. LDP ↔ MCP Agent Handoff

```json
{
  "context_id": "ctx_abc123",
  "user_facts": {
    "prefers_meeting_length": "45min",
    "most_important_contact": "[Person A]",
    "current_project": "LDP spec v1.0"
  },
  "relevant_history": [
    {"source": "calendar", "fact": "free Tuesday 3-4pm"},
    {"source": "email", "fact": "[Person A] waiting on project update"}
  ],
  "suggested_action": "schedule_meeting",
  "anonymised": true,
  "real_names_map_local_only": true
}
```

MCP agent receives context, acts intelligently. Real names stay local. De-anonymisation after MCP responds.

---

## 12. Audit Log

Append-only JSONL at `~/.pact/audit.log`.

Records per action: `ts · session_id · msg_type · connector_id · adapter · scopes_used[] · semantic_labels_accessed[] · ai_target · context_tokens_sent · response_tokens · e_code`

**Critical rule:** Values never in audit log. Labels only. "Accessed `caption` field" — never "caption said X."

---

## 13. Security Model — 7 Layers

1. No central server — nothing to breach remotely
2. AES-256-GCM hardware-derived key — stolen DB unreadable without exact machine
3. Localhost-only `127.0.0.1:7384` — unreachable from internet
4. Read-only enforcement — worst case: data read, apps not modified
5. Connector signing — AI assistants cannot silently add capabilities
6. Differential Privacy — cloud context mathematically noise-added
7. Open source — every security claim publicly verifiable

---

## 14. Versioning

- Patch (1.0.x): auto-update
- Minor (1.x.0): additive, auto-update with changelog
- Major (x.0.0): requires explicit user approval

---

## 15. What Is Proven vs Designed

| Component | Status | Evidence |
|---|---|---|
| Chrome history reading | **PROVEN** | 9,235 rows, 7 profiles, exact timestamps |
| Signal SQLCipher decrypt | **PROVEN** | macOS Keychain PBKDF2, working |
| MCP server in Cursor | **PROVEN** | Working in production |
| GitHub published | **DONE** | Live |
| Auto-discovery | Designed | Stage 2 |
| Agentic RAG | Designed | Stage 3 |
| Knowledge Distillation | Designed | Stage 3 |
| LangGraph agents | Designed | Stage 3 |
| Cloud bridge + NIM | Designed | Stage 4 |
| Federated Learning | Designed | Stage 5 |

---

## 16. Build Roadmap

```
DONE ✓
├── ldp_server.py (Chrome + Signal + 11 tools)
├── Cursor MCP integration
├── GitHub published
└── 9 critical bugs fixed + documented

STAGE 1 — Now
└── LDP_SPEC.md published to GitHub

STAGE 2 — Week 1-2
├── discover_machine() — AI auto-discover all apps
├── Fingerprint + Decrypt + Schema agents
└── LDP exposes as MCP server

STAGE 3 — Week 3-6
├── Agentic RAG (nomic-embed-text + LangGraph)
├── LangGraph supervisor + sub-agents
└── Knowledge Distillation Mode 1 (Cascade)

STAGE 4 — Month 2
├── Temporal Context Graph
├── Differential Privacy + Semantic Compression
├── PACT Dev app (Mac, public launch)
└── LDP Identity layer

STAGE 5 — Month 3
├── Federated Learning
├── Agent Marketplace
└── Connector Registry
```

---

## 17. Naming

**LDP** = Local Data Protocol — the protocol, the spec, the open standard
**PACT** = Personal AI Context Runtime — the product, what users install

---

## 18. Legal

- GDPR Art.20 + CCPA: user owns their data
- No server = no subpoena target
- User is data controller — DPIA on user not LDP
- MIT License
- GDPR Right to be Forgotten: delete local files, done

---

## 19. The Unfair Advantage

**LDP is simultaneously: local + private + any AI + any device + agentic + open source**

No competitor can be all six. Their business models prevent it.

The enterprise developer blocked from using Cursor because code cannot leave their network — that is PACT's first customer. Millions of them exist inside the companies that Copilot and Cursor claim to serve.

---

*LDP Specification v1.0 · March 2026 · MIT License*
