# PACT Dev
## Product Specification v1.0 · March 2026
### The AI that knows your entire coding life. Privately. Permanently.

---

> **Cursor knows your current file.**
> **PACT Dev knows your entire coding life.**
>
> Every repo. Every commit. Every command. Every decision.
> Permanently. Privately. On your machine.

---

## 1. What PACT Dev Is

PACT Dev is a Mac desktop AI tool for developers that reads your complete coding history — all repos, all git commits, all shell commands, all VS Code activity — and gives you intelligent answers about your own work. Powered by LDP protocol underneath.

**Platform:** macOS (first). Windows and Linux next.
**Launch:** Public. Product Hunt. Day one.
**Model:** Free (3 repos) → Pro $9/month (unlimited) → Team $29/user/month.

---

## 2. The Market Gap PACT Dev Fills

| Tool | What it knows | What it misses |
|---|---|---|
| Cursor | Current open file | Everything else |
| GitHub Copilot | Current repo | All other repos, history, shell |
| Claude Code | Current session | Permanent memory, cross-project |
| Hive Memory | Manual setup per project | Automatic, zero config |

**PACT Dev:** every repo you ever touched + full git history + shell history + VS Code + browser research + permanent memory. Zero configuration. Automatic.

**The enterprise wedge:** Many companies ban Cursor because code goes to Anthropic servers. PACT Dev: code never leaves device. Zero security review needed. Zero blocking.

---

## 3. What PACT Dev Reads (via LDP Layer 0)

All read locally. Zero cloud. One-time Full Disk Access permission at install.

```
Git repositories     — all repos found on disk
                       commits · diffs · branches · messages · authors
VS Code              — globalStorage/state.vscdb
                       recent files · workspaces · extensions · settings
Shell history        — ~/.zsh_history, ~/.bash_history
                       every command ever run
Terminal sessions    — recent commands + working directories
Browser (Chrome)     — research tabs · Stack Overflow · docs visited
Cursor AI history    — previous AI conversations about your code
Project files        — README · package.json · requirements.txt
```

---

## 4. The 5 Core Features

### Feature 1 — Codebase Memory

LDP reads every file you have ever touched across all repos. Agentic RAG indexes all of it locally.

```
Developer asks: "How did I handle JWT authentication in my last project?"
PACT Dev:       reads all repos → finds auth implementation → shows code + context
                "In your payments-api project (3 months ago) you used
                 jsonwebtoken with 24hr expiry. Here is the exact pattern..."
```

Cursor cannot do this. It only knows the currently open file.

### Feature 2 — Git Intelligence

LDP reads full git log across all repos — every commit message, every diff, every branch decision.

```
Developer asks: "What broke the payment flow in March?"
PACT Dev:       searches git history + diffs → finds the commit
                "Commit a4f82c on March 12: 'fix decimal precision' —
                 this changed float to int in calculateTotal(), removing
                 cents. 3 related commits followed as fixes."
```

### Feature 3 — Shell Intelligence

LDP reads complete shell history. PACT Dev understands your workflow.

```
Developer types: docker-compose
PACT Dev:        "You always follow docker-compose up with npm run dev
                  then curl localhost:3000/health — want me to run all three?"

Developer types: git push origin main
PACT Dev:        "Last time you pushed to main without a tag the CI
                  pipeline failed. You usually run npm test first."
```

### Feature 4 — Cross-Project Intelligence

Reads ALL repos simultaneously. Finds patterns impossible from any single project.

```
PACT Dev notices: "You implement the same authentication pattern in
                   every project (5 repos). I have extracted it into
                   a reusable module at ~/pact-extracted/auth-utils.ts"

PACT Dev notices: "Your API error handling in project-b is more
                   robust than in project-a which is in production.
                   Want me to show you the diff?"
```

### Feature 5 — Daily Dev Briefing

Every morning. Generated locally. Zero cloud.

```
Good morning. Here is your dev briefing for Tuesday March 21:

Yesterday you committed 847 lines across 3 files in payments-api.
The refactor of calculateOrder() is 60% complete based on your TODO comments.

⚠ 2 tests are currently failing (test_decimal_precision, test_edge_cases).
You left a console.log on line 142 of api/routes.js.

Today's focus based on your git notes: finish the refactor, then PR review
for @team-member whose PR has been waiting 3 days.

Your most productive coding window historically: 9am-12pm.
```

---

## 5. What PACT Dev Can Answer

```
"Why did I build the auth system this way?"
  → git commits + code comments + browser research history combined

"What was I working on last Tuesday?"
  → shell history + git commits + VS Code activity

"Show me every time I've solved a pagination problem"
  → searches all repos + shell history

"What commands do I run before every deployment?"
  → shell history pattern analysis

"Which of my projects has the most technical debt?"
  → code complexity + TODO count + commit frequency + test coverage

"What did I learn about React hooks last month?"
  → browser history (Stack Overflow, docs) + code changes that followed

"Generate a README for this project"
  → reads codebase + git history + understands purpose from commits

"What decisions did I make that I haven't documented?"
  → compares git commit scope vs code comments + missing README sections
```

---

## 6. Privacy Architecture

Everything runs locally. Nothing sent to cloud without explicit user choice.

```
All git data         → read locally by LDP
All shell history    → read locally by LDP
All VS Code data     → read locally by LDP
Agentic RAG index    → built locally (nomic-embed-text via Ollama)
AI answers           → Ollama locally by default

Optional cloud mode (user opt-in):
  LDP anonymises code context (strips credentials, API keys, emails)
  Sends anonymised snippets to Claude/GPT for harder questions
  Raw code never sent — only semantic descriptions
```

**Enterprise mode:** 100% local. Ollama only. No network calls ever. Passes any security review.

---

## 7. Interface — Mac Menu Bar App

Sits in menu bar. One click opens. Type question. Get answer.

```
┌─────────────────────────────────────────┐
│  PACT Dev                          ⚙️ ✕ │
├─────────────────────────────────────────┤
│                                         │
│  ● 14 repos indexed · 3,847 commits     │
│  ● Last updated: 2 minutes ago          │
│                                         │
│  ┌─────────────────────────────────┐    │
│  │ Ask about your code...          │    │
│  └─────────────────────────────────┘    │
│                                         │
│  Recent:                                │
│  • "How did I handle auth in..."  →     │
│  • "What broke in March?"         →     │
│  • "Daily briefing"               →     │
│                                         │
│  Insights:                              │
│  💡 2 failing tests detected            │
│  💡 Repeated pattern found (3 repos)    │
│                                         │
└─────────────────────────────────────────┘
```

**No IDE plugin needed.** Works alongside any editor. Cursor, VS Code, Vim, whatever. PACT Dev reads from disk — not from the IDE.

---

## 8. Installation

```bash
# Option 1: DMG installer (recommended)
# Download PACT-Dev.dmg from pact.dev
# Drag to Applications
# Grant Full Disk Access when prompted (one time)
# Done. PACT Dev starts indexing.

# Option 2: Homebrew
brew install --cask pact-dev

# Option 3: Direct (developers)
pip install pact-dev
pact init
pact start
```

First index: ~60 seconds for 10 repos. Progressive — answers available in 5 seconds for recent work.

---

## 9. Pricing

| Tier | Price | What |
|---|---|---|
| Free | $0 | 3 repos · Ollama local AI · basic queries |
| Pro | $9/month | Unlimited repos · daily briefing · cross-project insights · cloud AI option |
| Team | $29/user/month | Shared team memory · admin dashboard · enterprise support · 100% local mode |

**Revenue projection (conservative):**
- Cursor converts 35% free → paid
- PACT Dev target: 10,000 users year 1
- At 30% conversion: 3,000 Pro users × $9 = $324,000 ARR
- 50 team customers × 20 users × $29 = $348,000 ARR
- Year 1 total: ~$672,000 ARR. Fully bootstrappable.

---

## 10. Why Developers Will Switch

```
Pain with Cursor/Copilot today:
  "I have to explain my codebase every single session"
  "It doesn't remember decisions I made 3 months ago"
  "It can't see patterns across my projects"
  "My company won't let me use it — security policy"
  "It doesn't know why I built things this way"

PACT Dev solves all five. Permanently.
```

**The demo that converts:** Open PACT Dev. Ask "what was I working on last Tuesday and why?" Watch it answer from your git commits + shell history + VS Code. No setup. No context window pasting. Just the answer.

---

## 11. How PACT Dev Proves LDP Protocol

Every developer using PACT Dev is testing LDP in production:

| PACT Dev feature | LDP layer tested |
|---|---|
| Reading all repos | Layer 0: Auto-discovery |
| Cross-project insights | Layer 4: Temporal Context Graph |
| Daily briefing | Layer 3: LangGraph agents |
| Zero cloud mode | Layer 5: Privacy Engine |
| Shell intelligence | Layer 0: Plain text adapter |
| Git intelligence | Layer 1: Agentic RAG on commit history |

Every bug fixed in PACT Dev makes LDP stronger. Every feature PACT Dev needs becomes LDP protocol. The app and the protocol build each other simultaneously.

---

## 12. Build Order (4 Weeks to Launch)

```
Week 1 — Data layer (mostly done)
├── ✓ Shell history reader (ldp_server.py)
├── ✓ VS Code reader (ldp_server.py)
├── Add: git log reader (all repos on disk)
├── Add: file watcher for code changes
└── LDP exposes as MCP server

Week 2 — Intelligence layer
├── Agentic RAG indexes all code locally
├── nomic-embed-text via Ollama
├── Cross-project semantic search
└── LangGraph daily briefing agent

Week 3 — Mac app
├── Menu bar app (Electron or Swift)
├── Simple chat interface
├── Insight notifications
└── Settings (repos, AI model, privacy)

Week 4 — Polish + Launch
├── DMG installer
├── Homebrew formula
├── pact.dev website
├── Product Hunt launch
└── Hacker News: "Show HN: PACT Dev"
```

---

## 13. Positioning Statement

**For developers who cannot or will not send their code to the cloud.**

PACT Dev is the only developer AI with permanent memory of your entire coding history — every repo, every commit, every command, every decision — running completely privately on your Mac.

Cursor knows your current file. PACT Dev knows your entire coding life.

---

*PACT Dev Product Spec v1.0 · March 2026*
*Powered by LDP Protocol v1.0*
*Platform: macOS first · MIT License*
